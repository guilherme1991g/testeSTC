const firebaseConfig = {
    apiKey: "AIzaSyAx7QEvYUplmxg7pk6I3Bd99F5y-F1MoO8",
    authDomain: "triton-331e9.firebaseapp.com",
    projectId: "triton-331e9",
    storageBucket: "triton-331e9.appspot.com",
    messagingSenderId: "915939586386",
    appId: "1:915939586386:web:4fd37cee5bfa51f2614a8b",
    measurementId: "G-KQ8MY42QT1"
  };
firebase.initializeApp(firebaseConfig);