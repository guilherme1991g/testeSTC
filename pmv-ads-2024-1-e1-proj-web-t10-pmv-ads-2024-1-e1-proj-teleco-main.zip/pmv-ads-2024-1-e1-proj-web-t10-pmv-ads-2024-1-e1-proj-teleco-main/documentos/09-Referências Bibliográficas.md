# Referências Bibliográficas

[Inclua todas as referências (livros, artigos, sites, etc) utilizados no desenvolvimento do trabalho.]

SANTOS, Larissa dos. Como escrever boas histórias de usuário(user stories) abril, 2017.
Disponível em: https://medium.com/vertice/como-escrever-boas-users-stories-histórias-deusuários-b29c75043fac

API de referência disponível em: \
https://documenter.getpostman.com/view/6682240/Tz5s5whG.

MIKWEB. Sistema de gerenciamento para provedores. Dezembro, 2022.
Disponivel em: https://www.mikweb.com.br/preco-ou-qualidade-na-escolha-so-sgp-sistemade-gerenciamento-para-provedores-veja-os-impactos/

SGP usada para referência disponivel em: \
https://demo.sgp.net.br/accounts/login?next=/admin/

> **Links Úteis**:
> - [Formato ABNT](https://www.normastecnicas.com/abnt/)
> - [Referências Bibliográficas da ABNT](https://comunidade.rockcontent.com/referencia-bibliografica-abnt/)
