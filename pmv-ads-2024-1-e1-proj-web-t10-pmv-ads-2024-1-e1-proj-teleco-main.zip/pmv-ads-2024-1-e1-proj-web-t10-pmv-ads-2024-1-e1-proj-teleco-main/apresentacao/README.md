# Apresentação do Projeto

## Conjunto de Slides


[Presentation 1.pdf](https://github.com/user-attachments/files/15945800/Presentation.1.pdf)



## Vídeo de apresentação





https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2024-1-e1-proj-web-t10-pmv-ads-2024-1-e1-proj-teleco/assets/160364665/ac0e58cc-bc7f-4824-a5d1-a65a7ecb31c4



## Hospedagem

(https://icei-puc-minas-pmv-ads.github.io/pmv-ads-2024-1-e1-proj-web-t10-pmv-ads-2024-1-e1-proj-teleco/codigo-fonte/index.html)



